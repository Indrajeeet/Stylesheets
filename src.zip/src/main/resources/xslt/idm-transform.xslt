<?xml version="1.0" encoding="UTF-8"?>
<!--
  IDM Simplifier - Core XSLT Stylesheet
  =======================================
  Config-driven XML transformation that:
  1. Strips all namespaces from elements and attributes
  2. Applies keep/rename/remove rules from field-config.xml
  3. Uses whitelist approach (defaultAction="remove")
  
  Compatible with XSLT 1.0 (.NET, Mule 4 default).
  Uses a recursive named template to build element paths instead of XSLT 2.0 string-join().
-->
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:output method="xml" indent="yes" encoding="UTF-8" omit-xml-declaration="no"/>
    <xsl:strip-space elements="*"/>

    <!-- Load configuration file -->
    <xsl:variable name="config" select="document('../config/field-config.xml')"/>
    <xsl:variable name="defaultAction" select="$config/config/@defaultAction"/>

    <!-- ================================================================
         NAMED TEMPLATE: Build element path (XSLT 1.0 compatible)
         Builds "Root/Parent/Child" by recursing through ancestors.
         ================================================================ -->
    <xsl:template name="build-path">
        <xsl:for-each select="ancestor-or-self::*">
            <xsl:if test="position() > 1">/</xsl:if>
            <xsl:value-of select="local-name()"/>
        </xsl:for-each>
    </xsl:template>

    <!-- ================================================================
         MAIN TEMPLATE: Process each element
         ================================================================ -->
    <xsl:template match="*">
        <!-- Build the path using local-names (ignoring namespace prefixes) -->
        <xsl:variable name="path">
            <xsl:call-template name="build-path"/>
        </xsl:variable>

        <!-- Look up the rule for this path -->
        <xsl:variable name="rule" select="$config//rule[@sourcePath = $path]"/>

        <!-- Determine the effective action -->
        <xsl:variable name="action">
            <xsl:choose>
                <xsl:when test="$rule">
                    <xsl:value-of select="$rule/@action"/>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$defaultAction"/>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <xsl:choose>
            <!-- === REMOVE: Drop element and all children === -->
            <xsl:when test="$action = 'remove'">
                <!-- Element is silently dropped -->
            </xsl:when>

            <!-- === RENAME: Output element with new name, strip namespace === -->
            <xsl:when test="$action = 'rename'">
                <xsl:element name="{$rule/@targetName}">
                    <xsl:apply-templates select="@*"/>
                    <xsl:choose>
                        <xsl:when test="$rule/@children = 'apply-rules'">
                            <xsl:apply-templates select="node()"/>
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="."/>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:element>
            </xsl:when>

            <!-- === KEEP: Output element with local-name (strips namespace) === -->
            <xsl:when test="$action = 'keep'">
                <xsl:element name="{local-name()}">
                    <xsl:apply-templates select="@*"/>
                    <xsl:choose>
                        <xsl:when test="$rule/@children = 'apply-rules'">
                            <xsl:apply-templates select="node()"/>
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="."/>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:element>
            </xsl:when>
        </xsl:choose>
    </xsl:template>

    <!-- ================================================================
         ATTRIBUTE TEMPLATE: Strip namespaces from attributes
         ================================================================ -->
    <xsl:template match="@*">
        <xsl:if test="not(starts-with(name(), 'xmlns')) and namespace-uri() != 'http://www.w3.org/2001/XMLSchema-instance'">
            <xsl:attribute name="{local-name()}">
                <xsl:value-of select="."/>
            </xsl:attribute>
        </xsl:if>
    </xsl:template>

    <!-- ================================================================
         TEXT/COMMENT/PI: Preserve text, drop comments and PIs
         ================================================================ -->
    <xsl:template match="text()">
        <xsl:value-of select="normalize-space(.)"/>
    </xsl:template>

    <xsl:template match="comment() | processing-instruction()"/>

</xsl:stylesheet>
