<#
.SYNOPSIS
    Run-MigrationTest.ps1 -- Main Orchestrator
    Pentaho PDI -> Apache Hop Migration Validation Harness
#>

[CmdletBinding()]
param(
    [string] $ConfigFile       = ".\config\rules.json",
    [string] $PipelineId       = "",
    [switch] $SkipConnections
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$HarnessRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$RunId       = "MVR-{0}" -f (Get-Date -Format "yyyyMMdd-HHmmss")
$RunStart    = Get-Date

# -- Dot-source all modules ---------------------------------------------
. "$HarnessRoot\scripts\Invoke-Normalise.ps1"
. "$HarnessRoot\scripts\ConvertTo-CanonicalEvents.ps1"
. "$HarnessRoot\scripts\Get-EquivalenceScore.ps1"
. "$HarnessRoot\scripts\Find-KnownDivergence.ps1"
. "$HarnessRoot\scripts\Build-Verdict.ps1"
. "$HarnessRoot\scripts\Read-LogFile.ps1"
. "$HarnessRoot\scripts\Test-Connections.ps1"
. "$HarnessRoot\scripts\New-HtmlReport.ps1"
. "$HarnessRoot\scripts\New-JUnitReport.ps1"
. "$HarnessRoot\modules\Core\Initialize-KnowledgeBase.ps1"

Write-Host ""
Write-Host "=============================================================" -ForegroundColor Cyan
Write-Host "  PENTAHO -> HOP  MIGRATION VALIDATION HARNESS" -ForegroundColor Cyan
Write-Host "  Run ID : $RunId" -ForegroundColor Cyan
Write-Host "  Started: $RunStart" -ForegroundColor Cyan
Write-Host "=============================================================" -ForegroundColor Cyan

# -- Load configuration -------------------------------------------------
if (-not (Test-Path $ConfigFile)) { throw "Config not found: $ConfigFile" }
$Config = Get-Content $ConfigFile -Raw | ConvertFrom-Json

$KbPath  = Join-Path $HarnessRoot $Config.environment.knowledge_base
$KB = Initialize-KnowledgeBase -KnowledgeBasePath $KbPath

Write-Host "[INIT] Knowledge base loaded:" -ForegroundColor Green
Write-Host "       Patterns:    $($KB.Patterns.Count)"
Write-Host "       Divergences: $($KB.Divergences.Count)"
Write-Host "       Dimensions:  $($KB.Weights.dimensions.Count)"
Write-Host ""

$ResultsDir = Join-Path $HarnessRoot $Config.environment.results_root
if (-not (Test-Path $ResultsDir)) { New-Item -ItemType Directory -Path $ResultsDir -Force | Out-Null }

$Pipelines = $Config.pipelines | Where-Object { $_.enabled -eq $true }
if ($PipelineId -ne "") {
    $Pipelines = @($Pipelines | Where-Object { $_.id -eq $PipelineId })
    if ($Pipelines.Count -eq 0) { throw "Pipeline '$PipelineId' not found or not enabled." }
}

$ConnResults = @()
if (-not $SkipConnections) {
    Write-Host "-- STEP 1: Validating Connections -----------------------" -ForegroundColor Yellow
    $ActiveConns = $Config.connections | Where-Object { $_.enabled -eq $true }
    foreach ($Conn in $ActiveConns) {
        $CR = Test-MigrationConnection -Connection $Conn
        $ConnResults += $CR
        $icon = $(if ($CR.Status -eq "OK") { "[OK]" } else { "[X]" })
        $col  = $(if ($CR.Status -eq "OK") { "Green" } else { "Red" })
        Write-Host "  [$icon] $($CR.Id) ($($CR.Server)) -- $($CR.Status)" -ForegroundColor $col
    }
} else {
    Write-Host "-- STEP 1: Connections SKIPPED --------------------------" -ForegroundColor DarkYellow
}
Write-Host ""

Write-Host "-- STEP 2-4: Log Reading, Extraction, Comparison --------" -ForegroundColor Yellow
$AllResults = @()

foreach ($Pipeline in $Pipelines) {
    Write-Host ""
    Write-Host "  Pipeline: $($Pipeline.id)" -ForegroundColor White

    # ARCHITECTURE UPDATE: Try/Catch loop prevents bad files from crashing the harness
    try {
        $PentahoLogPath = Join-Path $HarnessRoot (Join-Path $Config.environment.pentaho_log_dir $Pipeline.pentaho_log_file)
        $HopLogPath     = Join-Path $HarnessRoot (Join-Path $Config.environment.hop_log_dir $Pipeline.hop_log_file)

        $PentahoLog = Read-MigrationLog -LogPath $PentahoLogPath -Platform "Pentaho"
        $HopLog     = Read-MigrationLog -LogPath $HopLogPath     -Platform "Hop"

        if (-not $PentahoLog.Found -or -not $HopLog.Found) {
            throw "Log file missing. Pentaho found: $($PentahoLog.Found) | Hop found: $($HopLog.Found)"
        }

        Write-Host "    [READ]    Pentaho: $($PentahoLog.LineCount) lines | Hop: $($HopLog.LineCount) lines"

        $PentahoNorm = @(Invoke-LogNormalise -LogLines $PentahoLog.Lines -Weights $KB.Weights)
        $HopNorm     = @(Invoke-LogNormalise -LogLines $HopLog.Lines     -Weights $KB.Weights)

        Write-Host "    [NORM]    Grace rules applied -- noise stripped"

        $PentahoEvents = @(ConvertTo-CanonicalEvents -NormLines $PentahoNorm -Platform "Pentaho" -Patterns $KB.Patterns)
        $HopEvents     = @(ConvertTo-CanonicalEvents -NormLines $HopNorm     -Platform "Hop"     -Patterns $KB.Patterns)

        Write-Host "    [EXTRACT] Pentaho: $($PentahoEvents.Count) events | Hop: $($HopEvents.Count) events"

        $Score = Get-EquivalenceScore -PentahoEvents $PentahoEvents -HopEvents $HopEvents -Pipeline $Pipeline -KB $KB
        Write-Host "    [SCORE]   $($Score.TotalScore)% across $($Score.Dimensions.Count) dimensions"

        $Divergences = @(Find-KnownDivergences -PentahoEvents $PentahoEvents -HopEvents $HopEvents -KB $KB)
        if ($Divergences.Count -gt 0) { Write-Host "    [DIVERGE] $($Divergences.Count) known divergence(s) matched" }

        $Verdict = Build-PipelineVerdict -Score $Score -Divergences $Divergences -Pipeline $Pipeline -KB $KB

        $col = switch ($Verdict.Verdict) { "PASS" { "Green" } "WARN" { "Yellow" } "FAIL" { "Red" } default { "Gray" } }
        Write-Host "    [VERDICT] $($Verdict.Verdict) -- $($Verdict.Summary)" -ForegroundColor $col

        $AllResults += [PSCustomObject]@{
            Pipeline = $Pipeline; PentahoLog = $PentahoLog; HopLog = $HopLog
            PentahoEvents = $PentahoEvents; HopEvents = $HopEvents
            Score = $Score; Divergences = $Divergences; Verdict = $Verdict
        }
    }
    catch {
        Write-Host "    [ERROR]   $($_.Exception.Message)" -ForegroundColor Red
        $Verdict = [PSCustomObject]@{
            Verdict = "FAIL"; Score = 0; Summary = "Internal Harness Error: $($_.Exception.Message)"
            ReasoningChain = @("[X] [SYSTEM ERROR] $($_.Exception.Message)"); Dimensions = @(); AppliedRules = @()
        }
        $AllResults += [PSCustomObject]@{
            Pipeline = $Pipeline; PentahoLog = $null; HopLog = $null
            PentahoEvents = @(); HopEvents = @(); Score = $null; Divergences = @(); Verdict = $Verdict
        }
    }
}

Write-Host ""
Write-Host "-- STEP 5: Building Run Summary -------------------------" -ForegroundColor Yellow

$RunSummary = [PSCustomObject]@{
    RunId           = $RunId
    StartTime       = $RunStart.ToString("o")
    EndTime         = (Get-Date).ToString("o")
    DurationSeconds = [math]::Round(((Get-Date) - $RunStart).TotalSeconds, 1)
    TotalPipelines  = @($AllResults).Count
    Passed          = @($AllResults | Where-Object { $_.Verdict.Verdict -eq "PASS" }).Count
    Warned          = @($AllResults | Where-Object { $_.Verdict.Verdict -eq "WARN" }).Count
    Failed          = @($AllResults | Where-Object { $_.Verdict.Verdict -eq "FAIL" }).Count
    Skipped         = (@($Pipelines).Count - @($AllResults).Count)
    OverallVerdict  = $(if (@($AllResults | Where-Object { $_.Verdict.Verdict -eq "FAIL" }).Count -gt 0) { "FAIL" }
                      elseif (@($AllResults | Where-Object { $_.Verdict.Verdict -eq "WARN" }).Count -gt 0) { "WARN" }
                      else  { "PASS" })
    Results         = $AllResults
    ConnResults     = $ConnResults
    Config          = $Config
    KB              = $KB
}

$JsonPath = "$ResultsDir\$RunId-summary.json"
$RunSummary | Select-Object RunId,StartTime,EndTime,DurationSeconds,TotalPipelines,Passed,Warned,Failed,Skipped,OverallVerdict |
    ConvertTo-Json | Set-Content $JsonPath -Encoding UTF8
Write-Host "[OK] JSON summary: $JsonPath"

Write-Host ""
Write-Host "-- STEP 6: Generating Reports ---------------------------" -ForegroundColor Yellow

$HtmlPath = "$ResultsDir\$RunId-report.html"
New-MigrationHtmlReport -RunSummary $RunSummary -OutputPath $HtmlPath
Write-Host "[OK] HTML report:  $HtmlPath"

# ARCHITECTURE UPDATE: CI/CD JUnit output
$JunitPath = "$ResultsDir\$RunId-junit.xml"
New-MigrationJUnitReport -RunSummary $RunSummary -OutputPath $JunitPath
Write-Host "[OK] JUnit report: $JunitPath"

Write-Host ""
Write-Host "=============================================================" -ForegroundColor Cyan
$vc = switch ($RunSummary.OverallVerdict) { "PASS" { "Green" } "WARN" { "Yellow" } "FAIL" { "Red" } }
Write-Host ("  VERDICT  : {0}" -f $RunSummary.OverallVerdict) -ForegroundColor $vc
Write-Host ("  Passed   : {0} / {1}" -f $RunSummary.Passed, $RunSummary.TotalPipelines)
Write-Host ("  Warned   : {0}"       -f $RunSummary.Warned)
Write-Host ("  Failed   : {0}"       -f $RunSummary.Failed)
Write-Host ("  Duration : {0}s"      -f $RunSummary.DurationSeconds)
Write-Host "=============================================================" -ForegroundColor Cyan
Write-Host ""

if ($Config.report.open_after_run) { Start-Process $HtmlPath }
exit $(if ($RunSummary.OverallVerdict -eq "FAIL") { 1 } else { 0 })

