﻿function Read-MigrationLog {
    param(
        [Parameter(Mandatory)] [string] $LogPath,
        [Parameter(Mandatory)] [string] $Platform
    )

    if (-not (Test-Path $LogPath)) {
        return [PSCustomObject]@{
            Platform  = $Platform
            LogPath   = $LogPath
            Found     = $false
            LineCount = 0
            Lines     = @()
            Error     = "Log file not found: $LogPath"
        }
    }

    # PERFORMANCE UPDATE: Use native .NET for massive ETL log files instead of Get-Content
    $Lines = [System.IO.File]::ReadAllLines($LogPath, [System.Text.Encoding]::UTF8)

    return [PSCustomObject]@{
        Platform  = $Platform
        LogPath   = $LogPath
        Found     = $true
        LineCount = $Lines.Count
        Lines     = $Lines
        Error     = $null
    }
}

