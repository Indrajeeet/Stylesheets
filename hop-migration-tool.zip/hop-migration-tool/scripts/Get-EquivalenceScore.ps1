﻿<#
.SYNOPSIS
    Get-EquivalenceScore.ps1
    The scoring engine. Compares canonical event sets across weighted dimensions
    and returns a detailed score object with per-dimension breakdowns.
    Every decision is traceable to a specific dimension and rule.
#>

function Get-EquivalenceScore {
    param(
        [Parameter(Mandatory)] $PentahoEvents,
        [Parameter(Mandatory)] $HopEvents,
        [Parameter(Mandatory)] $Pipeline,
        [Parameter(Mandatory)] $KB
    )

    $Dimensions   = $KB.Weights.dimensions
    $DimResults   = @()
    $TotalWeight  = ($Dimensions | Measure-Object -Property weight -Sum).Sum

    # -- Pre-compute event buckets --------------------------------------
    $PExitSuccess = $PentahoEvents | Where-Object EventType -eq "JOB_FINISHED_SUCCESS"
    $PExitFail    = $PentahoEvents | Where-Object EventType -eq "JOB_FINISHED_FAILURE"
    $HExitSuccess = $HopEvents     | Where-Object EventType -eq "JOB_FINISHED_SUCCESS"
    $HExitFail    = $HopEvents     | Where-Object EventType -eq "JOB_FINISHED_FAILURE"

    $PExitCode = $(if ($PExitSuccess) { 0 } elseif ($PExitFail) { 1 } else { -1 })
    $HExitCode = $(if ($HExitSuccess) { 0 } elseif ($HExitFail) { 1 } else { -1 })

    $PErrors   = @($PentahoEvents | Where-Object EventType -eq "ERROR_LINE")
    $HErrors   = @($HopEvents     | Where-Object EventType -eq "ERROR_LINE")
    $PWarnings = @($PentahoEvents | Where-Object EventType -eq "WARNING_LINE")
    $HWarnings = @($HopEvents     | Where-Object EventType -eq "WARNING_LINE")

    $PSteps = @($PentahoEvents | Where-Object EventType -eq "STEP_FINISHED")
    $HSteps = @($HopEvents     | Where-Object EventType -eq "STEP_FINISHED")

    $PRowEvents = @($PentahoEvents | Where-Object { $_.EventType -in @("ROWS_READ","ROWS_WRITTEN") })
    $HRowEvents = @($HopEvents     | Where-Object { $_.EventType -in @("ROWS_READ","ROWS_WRITTEN") })

    $HardFail = $false

    foreach ($Dim in $Dimensions) {

        $DimScore   = 0.0
        $DimVerdict = "PASS"
        $DimDetail  = ""
        $DimData    = $null

        switch ($Dim.id) {

            # -- Exit Code ------------------------------------------------
            "exit_code" {
                if ($PExitCode -eq $HExitCode) {
                    $DimScore   = $Dim.weight
                    $DimVerdict = "PASS"
                    $DimDetail  = "Both exited with code $PExitCode"
                } else {
                    $DimScore   = 0
                    $DimVerdict = "FAIL"
                    $DimDetail  = "Pentaho=$PExitCode, Hop=$HExitCode - exit code mismatch"
                    if ($Dim.hard_fail) { $HardFail = $true }
                }
                $DimData = @{ Pentaho = $PExitCode; Hop = $HExitCode }
            }

            # -- Step Count -----------------------------------------------
            "step_count" {
                if ($PSteps.Count -eq $HSteps.Count) {
                    $DimScore   = $Dim.weight
                    $DimVerdict = "PASS"
                    $DimDetail  = "$($PSteps.Count) steps executed on both platforms"
                } else {
                    $DimScore   = 0
                    $DimVerdict = "FAIL"
                    $DimDetail  = "Pentaho=$($PSteps.Count) steps, Hop=$($HSteps.Count) steps"
                }
                $DimData = @{ Pentaho = $PSteps.Count; Hop = $HSteps.Count }
            }

            # -- Row Counts -----------------------------------------------
            "row_counts" {
                $Tolerance = $Pipeline.row_count_tolerance_pct / 100.0

                # Group row events by step name
                $PRowMap = @{}
                foreach ($E in $PRowEvents) {
                    if ($E.StepName) {
                        $Key = "$($E.EventType):$($E.StepName)"
                        if (-not $PRowMap.ContainsKey($Key) -or $E.RowCount -gt $PRowMap[$Key].RowCount) {
                            $PRowMap[$Key] = $E
                        }
                    }
                }

                $HRowMap = @{}
                foreach ($E in $HRowEvents) {
                    if ($E.StepName) {
                        $Key = "$($E.EventType):$($E.StepName)"
                        if (-not $HRowMap.ContainsKey($Key) -or $E.RowCount -gt $HRowMap[$Key].RowCount) {
                            $HRowMap[$Key] = $E
                        }
                    }
                }

                $StepComparisons  = @()
                $TotalSteps       = 0
                $PassingSteps     = 0

                foreach ($Key in $PRowMap.Keys) {
                    $PE = $PRowMap[$Key]
                    $TotalSteps++

                    if ($HRowMap.ContainsKey($Key)) {
                        $HE      = $HRowMap[$Key]
                        $PRows   = $PE.RowCount
                        $HRows   = $HE.RowCount
                        $Delta   = $HRows - $PRows
                        $DiffPct = $(if ($PRows -gt 0) { [math]::Abs($Delta) / $PRows } else { if ($HRows -eq 0) { 0 } else { 1 } })

                        $StepV = $(if ($DiffPct -le $Tolerance) { "PASS"; $PassingSteps++ }
                                 elseif ($DiffPct -le ($Tolerance * 10 + 0.005)) { "WARN" }
                                 else { "FAIL" })

                        $StepComparisons += [PSCustomObject]@{
                            StepKey    = $Key
                            StepName   = $PE.StepName
                            EventType  = $PE.EventType
                            PentahoRows= $PRows
                            HopRows    = $HRows
                            Delta      = $Delta
                            DeltaPct   = [math]::Round($DiffPct * 100, 4)
                            Verdict    = $StepV
                        }
                    } else {
                        $StepComparisons += [PSCustomObject]@{
                            StepKey    = $Key
                            StepName   = $PE.StepName
                            EventType  = $PE.EventType
                            PentahoRows= $PE.RowCount
                            HopRows    = "MISSING"
                            Delta      = $null
                            DeltaPct   = $null
                            Verdict    = "FAIL"
                        }
                    }
                }

                $RowScore   = $(if ($TotalSteps -gt 0) { ($PassingSteps / $TotalSteps) * $Dim.weight } else { $Dim.weight })
                $DimScore   = [math]::Round($RowScore, 2)
                $DimVerdict = $(if ($DimScore -ge $Dim.weight) { "PASS" }
                              elseif ($DimScore -ge $Dim.weight * 0.8) { "WARN" }
                              else { "FAIL" })
                $DimDetail  = "$PassingSteps/$TotalSteps row-count checks passed (tolerance=$($Pipeline.row_count_tolerance_pct)%)"
                $DimData    = $StepComparisons
            }

            # -- Step Sequence --------------------------------------------
            "step_sequence" {
                $PSeq = @($PSteps | ForEach-Object { $_.StepName })
                $HSeq = @($HSteps | ForEach-Object { $_.StepName })

                $Matches_  = 0
                $MaxLen    = [math]::Max($PSeq.Count, 1)
                for ($i = 0; $i -lt [math]::Min($PSeq.Count, $HSeq.Count); $i++) {
                    if ($PSeq[$i] -eq $HSeq[$i]) { $Matches_++ }
                }

                $SeqPct    = $Matches_ / $MaxLen
                $DimScore  = [math]::Round($SeqPct * $Dim.weight, 2)
                $DimVerdict= $(if ($SeqPct -ge 1.0) { "PASS" } elseif ($SeqPct -ge 0.8) { "WARN" } else { "FAIL" })
                $DimDetail = "$Matches_/$($PSeq.Count) steps in correct sequence"
                $DimData   = @{ PentahoSequence = $PSeq; HopSequence = $HSeq }
            }

            # -- Error Count ----------------------------------------------
            "error_count" {
                if ($PErrors.Count -eq $HErrors.Count) {
                    $DimScore   = $Dim.weight
                    $DimVerdict = "PASS"
                    $DimDetail  = "Both have $($PErrors.Count) errors"
                } else {
                    $DimScore   = 0
                    $DimVerdict = "FAIL"
                    $DimDetail  = "Pentaho=$($PErrors.Count) errors, Hop=$($HErrors.Count) errors"
                }
                $DimData = @{ PentahoErrors = $PErrors.Count; HopErrors = $HErrors.Count }
            }

            # -- Warning Count --------------------------------------------
            "warning_count" {
                $WarnTol = $Dim.tolerance_pct / 100.0
                $PW      = $PWarnings.Count
                $HW      = $HWarnings.Count
                $WDiff   = $(if ($PW -gt 0) { [math]::Abs($PW - $HW) / $PW } else { if ($HW -eq 0) { 0 } else { 1 } })

                if ($WDiff -le $WarnTol) {
                    $DimScore   = $Dim.weight
                    $DimVerdict = "PASS"
                    $DimDetail  = "Pentaho=$PW, Hop=$HW warnings (within $($Dim.tolerance_pct)% tolerance)"
                } else {
                    $DimScore   = [math]::Round((1 - [math]::Min($WDiff, 1)) * $Dim.weight, 2)
                    $DimVerdict = "WARN"
                    $DimDetail  = "Pentaho=$PW, Hop=$HW warnings (delta=$('{0:P1}' -f $WDiff))"
                }
                $DimData = @{ PentahoWarnings = $PW; HopWarnings = $HW }
            }
        }

        $DimResults += [PSCustomObject]@{
            DimensionId  = $Dim.id
            Label        = $Dim.label
            Weight       = $Dim.weight
            Score        = $DimScore
            MaxScore     = $Dim.weight
            Verdict      = $DimVerdict
            Detail       = $DimDetail
            Data         = $DimData
        }
    }

    $TotalScore = [math]::Round(
        ($DimResults | Measure-Object -Property Score -Sum).Sum / $TotalWeight * 100,
        1
    )

    return [PSCustomObject]@{
        TotalScore  = $TotalScore
        HardFail    = $HardFail
        Dimensions  = $DimResults
        PentahoExit = $PExitCode
        HopExit     = $HExitCode
    }
}


