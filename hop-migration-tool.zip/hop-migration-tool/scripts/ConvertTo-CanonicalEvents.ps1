﻿<#
.SYNOPSIS
    ConvertTo-CanonicalEvents.ps1
    The semantic extraction engine. Applies the pattern library to normalised
    log lines and converts them into typed canonical event objects.
    Both Pentaho and Hop logs produce the SAME canonical schema -
    making comparison pure structured data matching, not string diffing.
#>

function ConvertTo-CanonicalEvents {
    param(
        [Parameter(Mandatory)] [string[]] $NormLines,
        [Parameter(Mandatory)] [string]   $Platform,
        [Parameter(Mandatory)]            $Patterns
    )

    $Events = [System.Collections.Generic.List[object]]::new()

    foreach ($Line in $NormLines) {

        foreach ($P in $Patterns) {

            # Select the right platform pattern
            $PatternStr = $(if ($Platform -eq "Pentaho") { $P.pentaho.pattern } else { $P.hop.pattern })
            if (-not $PatternStr) { continue }

            if ($Line -match $PatternStr) {

                # Build base event
                $Event = [PSCustomObject]@{
                    EventType   = $P.event_type
                    PatternId   = $P.id
                    Platform    = $Platform
                    RawLine     = $Line
                    StepName    = $null
                    RowCount    = $null
                    Status      = $null
                    Message     = $null
                    ConnName    = $null
                }

                # Extract named captures and apply normalisation
                foreach ($Field in $P.canonical_fields) {

                    $RawValue = $null

                    # Try named captures from regex
                    switch ($Field) {
                        "step_name" {
                            $RawValue = $(if ($Matches["step"])  { $Matches["step"] }
                                        elseif ($Matches["step2"]) { $Matches["step2"] }
                                        else { $null })
                        }
                        "row_count" {
                            $RawValue = $(if ($Matches["rows"]) { $Matches["rows"] } else { $null })
                        }
                        "message" {
                            $RawValue = $(if ($Matches["message"]) { $Matches["message"] } else { $null })
                        }
                        "pipeline_name" {
                            $RawValue = $(if ($Matches["name"]) { $Matches["name"] } else { $null })
                        }
                        "connection_name" {
                            $RawValue = $(if ($Matches["conn"]) { $Matches["conn"] } else { $null })
                        }
                    }

                    if ($null -eq $RawValue) { continue }

                    # Apply normalisation transforms
                    $NormOps = $P.normalise.$Field
                    $Value   = $RawValue

                    if ($NormOps) {
                        foreach ($Op in $NormOps) {
                            switch ($Op) {
                                "trim"                    { $Value = $Value.Trim() }
                                "lowercase"               { $Value = $Value.ToLower() }
                                "remove_suffix_dot_number"{ $Value = $Value -replace '\.\d+$', '' }
                                "remove_commas"           { $Value = $Value -replace ',', '' }
                                "to_integer"              { $Value = [int]$Value }
                                "remove_brackets"         { $Value = $Value -replace '[\[\]]', '' }
                                "remove_timestamps"       { $Value = $Value -replace '{{TIMESTAMP}}', '' }
                                "remove_guids"            { $Value = $Value -replace '{{GUID}}', '' }
                                "normalise_field_names"   { $Value = $Value -replace '\s+', ' ' }
                            }
                        }
                    }

                    # Map normalised value to canonical field
                    switch ($Field) {
                        "step_name"       { $Event.StepName  = $Value }
                        "row_count"       { $Event.RowCount  = $Value }
                        "message"         { $Event.Message   = $Value }
                        "connection_name" { $Event.ConnName  = $Value }
                        "pipeline_name"   { $Event.StepName  = $Value }
                    }
                }

                # Infer status from event type
                $Event.Status = switch ($P.event_type) {
                    "JOB_FINISHED_SUCCESS" { "SUCCESS" }
                    "JOB_FINISHED_FAILURE" { "FAILURE" }
                    "ERROR_LINE"           { "ERROR" }
                    "WARNING_LINE"         { "WARNING" }
                    default                { "OK" }
                }

                $Events.Add($Event)
                break  # First matching pattern wins per line
            }
        }
    }

    return $Events.ToArray()
}


