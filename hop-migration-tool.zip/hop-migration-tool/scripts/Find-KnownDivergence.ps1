﻿<#
.SYNOPSIS
    Find-KnownDivergence.ps1
    Matches canonical event pairs against the known_divergences knowledge base.
    Returns every divergence that was matched, with the evidence that triggered it.
    This is the "learned experience" layer of the inference engine.
#>

function Find-KnownDivergences {
    param(
        [Parameter(Mandatory)] $PentahoEvents,
        [Parameter(Mandatory)] $HopEvents,
        [Parameter(Mandatory)] $KB
    )

    $Matched = @()

    $PRowEvents = @($PentahoEvents | Where-Object { $_.EventType -in @("ROWS_READ","ROWS_WRITTEN") })
    $HRowEvents = @($HopEvents     | Where-Object { $_.EventType -in @("ROWS_READ","ROWS_WRITTEN") })
    $PWarnings  = @($PentahoEvents | Where-Object EventType -eq "WARNING_LINE")
    $HWarnings  = @($HopEvents     | Where-Object EventType -eq "WARNING_LINE")
    $PErrors    = @($PentahoEvents | Where-Object EventType -eq "ERROR_LINE")
    $HErrors    = @($HopEvents     | Where-Object EventType -eq "ERROR_LINE")

    foreach ($KD in $KB.Divergences) {

        $Evidence = $null

        switch ($KD.id) {

            # KD001 - CSV Input NULL rows
            "KD001" {
                $PCSVRows = $PRowEvents | Where-Object { $_.StepName -match "csv" }
                $HCSVRows = $HRowEvents | Where-Object { $_.StepName -match "csv" }
                foreach ($PE in $PCSVRows) {
                    $HE = $HCSVRows | Where-Object StepName -eq $PE.StepName | Select-Object -First 1
                    if ($HE -and $PE.RowCount -and $HE.RowCount) {
                        $Delta = $PE.RowCount - $HE.RowCount
                        if ($Delta -gt 0) {
                            $DeltaPct = $Delta / $PE.RowCount * 100
                            if ($DeltaPct -le 0.5) {
                                $Evidence = "CSV Input '$($PE.StepName)': Pentaho=$($PE.RowCount), Hop=$($HE.RowCount), Delta=$Delta rows ($([math]::Round($DeltaPct,4))%)"
                            }
                        }
                    }
                }
            }

            # KD002 - String Operations whitespace
            "KD002" {
                $PStrOps = $PentahoEvents | Where-Object { $_.StepName -match "string" }
                $HStrOps = $HopEvents     | Where-Object { $_.StepName -match "string" }
                if ($PStrOps -and $HStrOps) {
                    $Evidence = "String Operations step present in both logs - trailing whitespace difference may apply"
                }
            }

            # KD003 - Merge Join default type
            "KD003" {
                $PJoinRows = $PRowEvents | Where-Object { $_.StepName -match "merge|join" }
                $HJoinRows = $HRowEvents | Where-Object { $_.StepName -match "merge|join" }
                foreach ($PE in $PJoinRows) {
                    $HE = $HJoinRows | Where-Object StepName -eq $PE.StepName | Select-Object -First 1
                    if ($HE -and $PE.RowCount -and $HE.RowCount -and $PE.RowCount -gt 0) {
                        $DeltaPct = [math]::Abs($PE.RowCount - $HE.RowCount) / $PE.RowCount * 100
                        if ($DeltaPct -gt 0.5) {
                            $Evidence = "Merge Join '$($PE.StepName)': Pentaho=$($PE.RowCount), Hop=$($HE.RowCount), Delta=$([math]::Round($DeltaPct,2))% - possible JOIN TYPE mismatch"
                        }
                    }
                }
            }

            # KD004 - Higher warning count in Hop
            "KD004" {
                if ($HWarnings.Count -gt $PWarnings.Count -and $PWarnings.Count -gt 0) {
                    $Ratio = [math]::Round($HWarnings.Count / $PWarnings.Count, 2)
                    if ($Ratio -ge 1.5 -and $Ratio -le 5.0) {
                        $Evidence = "Hop warnings=$($HWarnings.Count), Pentaho warnings=$($PWarnings.Count), ratio=$Ratio - consistent with per-field NULL warning behaviour"
                    }
                }
            }

            # KD006 - Step naming suffix (always present, informational)
            "KD006" {
                $SuffixSteps = $PentahoEvents | Where-Object { $_.RawLine -match '\.\d+\s+-' } | Select-Object -First 1
                if ($SuffixSteps) {
                    $Evidence = "Pentaho step name suffixes (.0, .1) detected and normalised by pattern SP001/SP002"
                }
            }

            # KD007 - Timestamp format (always present)
            "KD007" {
                $Evidence = "Timestamp format differences handled by GRACE-TS rule - both logs normalised to {{TIMESTAMP}}"
            }

            # KD008 - Sort Rows spill
            "KD008" {
                $SortSpill = $HWarnings | Where-Object { $_.Message -match "sort.*disk|disk.*sort|spill" }
                if ($SortSpill) {
                    $Evidence = "Hop Sort Rows disk-spill warning detected: '$($SortSpill[0].Message)'"
                }
            }

            # KD009 - JavaScript engine error
            "KD009" {
                $JsError = $HErrors | Where-Object { $_.Message -match "ReferenceError|importPackage|GraalVM|Rhino" }
                if ($JsError) {
                    $Evidence = "JavaScript engine error in Hop: '$($JsError[0].Message)' - GraalVM vs Rhino incompatibility"
                }
            }

            # KD010 - Table Output commit size
            "KD010" {
                $PCommits = @($PentahoEvents | Where-Object { $_.RawLine -match "commit|flushing" })
                $HCommits = @($HopEvents     | Where-Object { $_.RawLine -match "commit|flushing" })
                if ($PCommits.Count -ne $HCommits.Count -and ($PCommits.Count + $HCommits.Count) -gt 0) {
                    $Evidence = "Commit log count: Pentaho=$($PCommits.Count), Hop=$($HCommits.Count) - default commit size difference"
                }
            }
        }

        if ($Evidence) {
            $Matched += [PSCustomObject]@{
                DivergenceId  = $KD.id
                Title         = $KD.title
                Category      = $KD.category
                Safe          = $KD.safe
                Verdict       = $KD.verdict
                RootCause     = $KD.root_cause
                RecommendedFix= $KD.recommended_fix
                Evidence      = $Evidence
            }
        }
    }

    return $Matched
}


