﻿<#
.SYNOPSIS
    Invoke-Normalise.ps1
    Applies all grace rules from equivalence_weights.json to a set of log lines.
    Returns a cleaned array of lines ready for canonical extraction.
    This is the noise-removal layer - timestamps, GUIDs, paths, versions all stripped.
#>

function Invoke-LogNormalise {
    param(
        [Parameter(Mandatory)] [string[]] $LogLines,
        [Parameter(Mandatory)]            $Weights
    )

    $Grace = $Weights.grace_rules
    $Result = [System.Collections.Generic.List[string]]::new()

    foreach ($Line in $LogLines) {
        $L = $Line

        # -- SKIP rules - remove entire line ----------------------------
        $ShouldSkip = $false

        foreach ($Pattern in $Grace.durations.patterns) {
            if ($L -match $Pattern) { $ShouldSkip = $true; break }
        }
        if (-not $ShouldSkip) {
            foreach ($Pattern in $Grace.memory.patterns) {
                if ($L -match $Pattern) { $ShouldSkip = $true; break }
            }
        }
        if (-not $ShouldSkip) {
            foreach ($Pattern in $Grace.version_strings.patterns) {
                if ($L -match $Pattern) { $ShouldSkip = $true; break }
            }
        }

        if ($ShouldSkip) { continue }

        # -- NORMALIZE rules - replace with placeholder ------------------

        # Timestamps -> {{TIMESTAMP}}
        foreach ($Pattern in $Grace.timestamps.patterns) {
            $L = $L -replace $Pattern, "{{TIMESTAMP}}"
        }

        # GUIDs -> {{GUID}}
        foreach ($Pattern in $Grace.guids.patterns) {
            $L = $L -replace $Pattern, $Grace.guids.placeholder
        }

        # Thread IDs -> {{THREAD}}
        foreach ($Pattern in $Grace.thread_ids.patterns) {
            $L = $L -replace $Pattern, $Grace.thread_ids.placeholder
        }

        # PIDs -> {{PID}}
        foreach ($Pattern in $Grace.pid.patterns) {
            $L = $L -replace $Pattern, $Grace.pid.placeholder
        }

        # File paths -> logical names
        foreach ($Replacement in $Grace.file_paths.replacements) {
            $L = $L -replace [regex]::Escape($Replacement.from), $Replacement.to
        }

        # Trim and skip empty lines
        $L = $L.Trim()
        if ($L -ne "") { $Result.Add($L) }
    }

    return $Result.ToArray()
}


