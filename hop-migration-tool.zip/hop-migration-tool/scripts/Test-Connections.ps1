﻿<#
.SYNOPSIS
    Test-Connections.ps1
    Validates all database connections defined in rules.json
    before pipeline comparison begins.
#>

function Test-MigrationConnection {
    param(
        [Parameter(Mandatory)] $Connection
    )

    $Result = [PSCustomObject]@{
        Id       = $Connection.id
        Type     = $Connection.type
        Server   = $Connection.server
        Port     = $Connection.port
        Database = $Connection.database
        Status   = "UNKNOWN"
        Message  = ""
        TestedAt = (Get-Date).ToString("o")
    }

    try {
        $User = [System.Environment]::GetEnvironmentVariable($Connection.credential_env_user)
        $Pass = [System.Environment]::GetEnvironmentVariable($Connection.credential_env_pass)

        if (-not $User -or -not $Pass) {
            throw "Env vars not set: $($Connection.credential_env_user) / $($Connection.credential_env_pass)"
        }

        switch ($Connection.type.ToLower()) {

            "sqlserver" {
                $CS  = "Server=$($Connection.server),$($Connection.port);Database=$($Connection.database);User Id=$User;Password=$Pass;Connection Timeout=10;"
                $Conn = New-Object System.Data.SqlClient.SqlConnection($CS)
                $Conn.Open()
                $Cmd = $Conn.CreateCommand()
                $Cmd.CommandText    = $Connection.validation_query
                $Cmd.CommandTimeout = 10
                $Cmd.ExecuteNonQuery() | Out-Null
                $Conn.Close()
                $Result.Status  = "OK"
                $Result.Message = "Connected successfully"
            }

            default {
                $TCP = New-Object System.Net.Sockets.TcpClient
                if ($TCP.ConnectAsync($Connection.server, $Connection.port).Wait(5000)) {
                    $Result.Status  = "OK"
                    $Result.Message = "TCP port reachable"
                } else {
                    throw "TCP connect timeout after 5s"
                }
                $TCP.Close()
            }
        }
    }
    catch {
        $Result.Status  = "FAIL"
        $Result.Message = $_.Exception.Message
    }

    return $Result
}


