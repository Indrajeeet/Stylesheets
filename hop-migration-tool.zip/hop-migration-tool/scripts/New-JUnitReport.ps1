﻿function New-MigrationJUnitReport {
    param(
        [Parameter(Mandatory)] $RunSummary,
        [Parameter(Mandatory)] [string] $OutputPath
    )

    $xml = @"
<?xml version="1.0" encoding="UTF-8"?>
<testsuites name="MigrationValidation" tests="$($RunSummary.TotalPipelines)" failures="$($RunSummary.Failed)" time="$($RunSummary.DurationSeconds)">
"@

    foreach ($R in $RunSummary.Results) {
        $fails = $(if ($R.Verdict.Verdict -eq 'FAIL') { 1 } else { 0 })
        $xml += "`n  <testsuite name=`"$($R.Pipeline.id)`" tests=`"1`" failures=`"$fails`">"
        $xml += "`n    <testcase name=`"$($R.Pipeline.id)`" classname=`"SemanticEquivalence`">"
        
        if ($R.Verdict.Verdict -eq "FAIL") {
            $safeSummary = [System.Security.SecurityElement]::Escape($R.Verdict.Summary)
            $safeDetail  = [System.Security.SecurityElement]::Escape($R.Verdict.ReasoningChain -join "`n")
            $xml += "`n      <failure message=`"$safeSummary`">`n$safeDetail`n      </failure>"
        }
        
        $xml += "`n    </testcase>"
        $xml += "`n  </testsuite>"
    }

    $xml += "`n</testsuites>"
    $xml | Set-Content $OutputPath -Encoding UTF8
}

