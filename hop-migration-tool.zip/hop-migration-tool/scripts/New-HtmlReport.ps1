<#
.SYNOPSIS
    New-HtmlReport.ps1
    Generates a premium HTML migration validation report.
    Shows matched crucial log entries side-by-side with semantic decisions,
    extracted canonical events, and full decision trace.
#>

function New-MigrationHtmlReport {
    param(
        [Parameter(Mandatory)] $RunSummary,
        [Parameter(Mandatory)] [string] $OutputPath
    )

    try { Add-Type -AssemblyName System.Web -ErrorAction SilentlyContinue } catch {}

    function he($s) { if ($s) { [System.Web.HttpUtility]::HtmlEncode($s) } else { "" } }
    function vc($v) { $(switch($v){"PASS"{"#10b981"}"WARN"{"#f59e0b"}"FAIL"{"#ef4444"}default{"#64748b"}}) }
    function vb($v) { $(switch($v){"PASS"{"rgba(16,185,129,0.10)"}"WARN"{"rgba(245,158,11,0.10)"}"FAIL"{"rgba(239,68,68,0.10)"}default{"rgba(100,116,139,0.10)"}}) }
    function vi($v) { $(switch($v){"PASS"{"&#10004;"}"WARN"{"&#9888;"}"FAIL"{"&#10008;"}default{"&#8226;"}}) }

    # ========================================================================
    # Classify a single log line into a category + extract step name
    # ========================================================================
    function Classify-LogLine {
        param([string]$Line, [string]$Platform)
        $cat = "OTHER"
        $step = ""
        $detail = ""

        if ([string]::IsNullOrWhiteSpace($Line)) { return $null }

        # Strip timestamp
        $stripped = $Line -replace '^\d{4}[-/]\d{2}[-/]\d{2}\s+\d{2}:\d{2}:\d{2}\s*-?\s*', ''

        if ($Platform -eq "Pentaho") {
            if ($stripped -match 'START of job') { $cat = "JOB_START"; $detail = $stripped }
            elseif ($stripped -match '(.*?)(?:\.\d+)?\s*-\s*INFO\s*.*?[Ff]inished reading\s+([\d,]+)\s+input rows') {
                $cat = "ROWS_READ"; $step = $Matches[1].Trim(); $detail = "Read $($Matches[2]) rows"
            }
            elseif ($stripped -match '(.*?)(?:\.\d+)?\s*-\s*INFO\s*.*?[Ff]inished writing\s+([\d,]+)\s+output rows') {
                $cat = "ROWS_WRITTEN"; $step = $Matches[1].Trim(); $detail = "Wrote $($Matches[2]) rows"
            }
            elseif ($stripped -match '(.*?)(?:\.\d+)?\s*-\s*INFO\s*.*?([\d,]+)\s+rows accepted') {
                $cat = "ROWS_ACCEPTED"; $step = $Matches[1].Trim(); $detail = "$($Matches[2]) rows accepted"
            }
            elseif ($stripped -match '(.*?)(?:\.\d+)?\s*-\s*INFO\s*.*?([\d,]+)\s+rows rejected') {
                $cat = "ROWS_REJECTED"; $step = $Matches[1].Trim(); $detail = "$($Matches[2]) rows rejected"
            }
            elseif ($stripped -match '(.*?)(?:\.\d+)?\s*-\s*INFO\s*.*?Finished processing') {
                $cat = "STEP_FINISH"; $step = $Matches[1].Trim(); $detail = "Step finished"
            }
            elseif ($stripped -match '(.*?)(?:\.\d+)?\s*-\s*INFO\s*.*?Started\s*$') {
                $cat = "STEP_START"; $step = $Matches[1].Trim(); $detail = "Step started"
            }
            elseif ($stripped -match '(.*?)(?:\.\d+)?\s*-\s*INFO\s*.*?Opening database connection\s*\[(.+?)\]') {
                $cat = "DB_CONNECT"; $step = $Matches[1].Trim(); $detail = "Connected to [$($Matches[2])]"
            }
            elseif ($stripped -match 'Job finished successfully|END of job execution') {
                $cat = "JOB_SUCCESS"; $detail = $stripped
            }
            elseif ($stripped -match 'ERROR') { $cat = "ERROR"; $detail = $stripped }
            elseif ($stripped -match 'WARN') { $cat = "WARNING"; $detail = $stripped }
            else { $cat = "INFO"; $detail = $stripped }
        }
        else {
            # Hop
            if ($stripped -match 'Pipeline .* - START') { $cat = "JOB_START"; $detail = $stripped }
            elseif ($stripped -match "Transform '(.+?)'\s*-\s*(\d+)\s+rows read") {
                $cat = "ROWS_READ"; $step = $Matches[1].Trim(); $detail = "Read $($Matches[2]) rows"
            }
            elseif ($stripped -match "Transform '(.+?)'\s*-\s*(\d+)\s+rows written") {
                $cat = "ROWS_WRITTEN"; $step = $Matches[1].Trim(); $detail = "Wrote $($Matches[2]) rows"
            }
            elseif ($stripped -match "Transform '(.+?)'\s*-\s*(\d+)\s+rows output") {
                $cat = "ROWS_ACCEPTED"; $step = $Matches[1].Trim(); $detail = "$($Matches[2]) rows output"
            }
            elseif ($stripped -match "Transform '(.+?)'\s*-\s*(\d+)\s+rows rejected") {
                $cat = "ROWS_REJECTED"; $step = $Matches[1].Trim(); $detail = "$($Matches[2]) rows rejected"
            }
            elseif ($stripped -match "Transform '(.+?)'\s*-\s*finished") {
                $cat = "STEP_FINISH"; $step = $Matches[1].Trim(); $detail = "Transform finished"
            }
            elseif ($stripped -match "Transform '(.+?)'\s*-\s*START") {
                $cat = "STEP_START"; $step = $Matches[1].Trim(); $detail = "Transform started"
            }
            elseif ($stripped -match 'Connecting to database connection\s*\[(.+?)\]') {
                $cat = "DB_CONNECT"; $step = ""; $detail = "Connected to [$($Matches[1])]"
                if ($stripped -match "Transform '(.+?)'") { $step = $Matches[1].Trim() }
                elseif ($stripped -match "^(.+?)\s*-\s*Connecting") { $step = $Matches[1].Trim() }
            }
            elseif ($stripped -match 'Pipeline .* - Finished|Workflow .* finished') {
                $cat = "JOB_SUCCESS"; $detail = $stripped
            }
            elseif ($stripped -match 'Apache Hop \d') { $cat = "PLATFORM_INFO"; $detail = $stripped }
            elseif ($stripped -match 'ERROR') { $cat = "ERROR"; $detail = $stripped }
            elseif ($stripped -match 'WARN') { $cat = "WARNING"; $detail = $stripped }
            else { $cat = "INFO"; $detail = $stripped }
        }

        return [PSCustomObject]@{
            Category = $cat
            StepName = $step
            Detail   = $detail
            RawLine  = $Line
        }
    }

    # ========================================================================
    # Match classified Pentaho and Hop entries into paired rows
    # ========================================================================
    function Build-MatchedEntries {
        param($PentahoLines, $HopLines)

        $PEntries = @()
        if ($PentahoLines) {
            foreach ($l in $PentahoLines) {
                $c = Classify-LogLine -Line $l -Platform "Pentaho"
                if ($c -and $c.Category -ne "OTHER") { $PEntries += $c }
            }
        }
        $HEntries = @()
        if ($HopLines) {
            foreach ($l in $HopLines) {
                $c = Classify-LogLine -Line $l -Platform "Hop"
                if ($c -and $c.Category -ne "OTHER" -and $c.Category -ne "PLATFORM_INFO") { $HEntries += $c }
            }
        }

        $Matched = @()
        $UsedH = @{}

        foreach ($P in $PEntries) {
            $bestH = $null
            $bestIdx = -1
            for ($i = 0; $i -lt $HEntries.Count; $i++) {
                if ($UsedH.ContainsKey($i)) { continue }
                $H = $HEntries[$i]
                if ($H.Category -eq $P.Category) {
                    # Prefer same step name
                    if ($P.StepName -and $H.StepName -and $P.StepName -eq $H.StepName) {
                        $bestH = $H; $bestIdx = $i; break
                    }
                    # If step name is empty on both (e.g. JOB_START), match
                    if (-not $P.StepName -and -not $H.StepName) {
                        $bestH = $H; $bestIdx = $i; break
                    }
                    # Fallback: same category, different step - keep searching
                    if (-not $bestH) { $bestH = $H; $bestIdx = $i }
                }
            }

            if ($bestH) {
                $UsedH[$bestIdx] = $true
                # Determine semantic verdict for this pair
                $sv = "MATCH"
                $comment = "Same operation. Surface formatting differs but semantically identical."
                if ($P.Category -eq "ROWS_READ" -or $P.Category -eq "ROWS_WRITTEN" -or $P.Category -eq "ROWS_ACCEPTED" -or $P.Category -eq "ROWS_REJECTED") {
                    $pNum = [regex]::Match($P.Detail, '[\d,]+').Value -replace ','
                    $hNum = [regex]::Match($bestH.Detail, '[\d,]+').Value -replace ','
                    if ($pNum -eq $hNum) {
                        $sv = "MATCH"; $comment = "Identical row counts ($pNum). Semantically equivalent."
                    } else {
                        $sv = "DELTA"; $comment = "Row count difference: Pentaho=$pNum, Hop=$hNum. Investigate tolerance."
                    }
                }
                elseif ($P.Category -eq "DB_CONNECT") {
                    $sv = "MATCH"; $comment = "Both connect to the same database. Connection mechanism differs only in syntax."
                }
                elseif ($P.Category -eq "JOB_START" -or $P.Category -eq "JOB_SUCCESS") {
                    $sv = "MATCH"; $comment = "Lifecycle event. Pentaho uses 'Job', Hop uses 'Pipeline'. Same meaning."
                }
                elseif ($P.Category -eq "STEP_START") {
                    $comment = "Both started the same step/transform. Pentaho uses 'Step', Hop uses 'Transform'. Same operation."
                }
                elseif ($P.Category -eq "STEP_FINISH") {
                    $comment = "Both finished the same step/transform. Execution completed identically."
                }
                elseif ($P.Category -eq "ERROR") {
                    $sv = "ERROR_MATCH"; $comment = "Both platforms reported errors. Review error messages for equivalence."
                }

                $Matched += [PSCustomObject]@{
                    Category      = $P.Category
                    StepName      = $(if($P.StepName){$P.StepName}else{$bestH.StepName})
                    PentahoDetail = $P.Detail
                    HopDetail     = $bestH.Detail
                    PentahoRaw    = $P.RawLine
                    HopRaw        = $bestH.RawLine
                    Verdict       = $sv
                    Comment       = $comment
                }
            } else {
                $Matched += [PSCustomObject]@{
                    Category      = $P.Category
                    StepName      = $P.StepName
                    PentahoDetail = $P.Detail
                    HopDetail     = "(no matching Hop entry)"
                    PentahoRaw    = $P.RawLine
                    HopRaw        = ""
                    Verdict       = "MISSING"
                    Comment       = "This Pentaho operation has no equivalent in the Hop log. Possible migration gap."
                }
            }
        }

        # Remaining unmatched Hop entries
        for ($i = 0; $i -lt $HEntries.Count; $i++) {
            if ($UsedH.ContainsKey($i)) { continue }
            $H = $HEntries[$i]
            $Matched += [PSCustomObject]@{
                Category      = $H.Category
                StepName      = $H.StepName
                PentahoDetail = "(no matching Pentaho entry)"
                HopDetail     = $H.Detail
                PentahoRaw    = ""
                HopRaw        = $H.RawLine
                Verdict       = "NEW"
                Comment       = "This Hop entry has no Pentaho equivalent. May be a new feature or format change."
            }
        }

        return $Matched
    }

    # ========================================================================
    # Category display labels and icons
    # ========================================================================
    function CategoryLabel($cat) {
        $(switch($cat){
            "JOB_START"     {"Execution Start"}
            "STEP_START"    {"Step Start"}
            "STEP_FINISH"   {"Step Finish"}
            "ROWS_READ"     {"Rows Read"}
            "ROWS_WRITTEN"  {"Rows Written"}
            "ROWS_ACCEPTED" {"Rows Accepted"}
            "ROWS_REJECTED" {"Rows Rejected"}
            "DB_CONNECT"    {"DB Connection"}
            "JOB_SUCCESS"   {"Execution Complete"}
            "ERROR"         {"Error"}
            "WARNING"       {"Warning"}
            "INFO"          {"Info"}
            default         {$cat}
        })
    }

    function VerdictColor($v) {
        $(switch($v){
            "MATCH"       {"#10b981"}
            "DELTA"       {"#f59e0b"}
            "MISSING"     {"#ef4444"}
            "NEW"         {"#38bdf8"}
            "ERROR_MATCH" {"#ef4444"}
            default       {"#64748b"}
        })
    }

    function VerdictIcon($v) {
        $(switch($v){
            "MATCH"       {"&#10004;"}
            "DELTA"       {"&#9651;"}
            "MISSING"     {"&#10008;"}
            "NEW"         {"&#43;"}
            "ERROR_MATCH" {"&#9888;"}
            default       {"&#8226;"}
        })
    }

    function VerdictLabel($v) {
        $(switch($v){
            "MATCH"       {"Semantically Identical"}
            "DELTA"       {"Value Difference"}
            "MISSING"     {"Missing in Hop"}
            "NEW"         {"New in Hop"}
            "ERROR_MATCH" {"Error on Both"}
            default       {$v}
        })
    }

    # ========================================================================
    # Build HTML
    # ========================================================================

    $OV      = $RunSummary.OverallVerdict
    $OVC     = vc $OV
    $Total   = $RunSummary.TotalPipelines
    $ConfPct = $(if ($Total -gt 0) {
        [math]::Round((($RunSummary.Passed + $RunSummary.Warned * 0.5) / $Total) * 100, 0)
    } else { 0 })

    $PipelineSections = ""
    $SidebarNavItems = ""
    $idx = 0

    foreach ($R in $RunSummary.Results) {
        $idx++
        $V       = $R.Verdict
        $Vcolor  = vc $V.Verdict
        $Score   = $V.Score

        $pLogCount = $(if ($R.PentahoLog) { $R.PentahoLog.LineCount } else { 0 })
        $hLogCount = $(if ($R.HopLog) { $R.HopLog.LineCount } else { 0 })
        $pEvCount  = $(if ($R.PentahoEvents) { $R.PentahoEvents.Count } else { 0 })
        $hEvCount  = $(if ($R.HopEvents) { $R.HopEvents.Count } else { 0 })

        # ---- Build matched entries table ----
        $pLines = $(if ($R.PentahoLog -and $R.PentahoLog.Lines) { $R.PentahoLog.Lines } else { @() })
        $hLines = $(if ($R.HopLog -and $R.HopLog.Lines) { $R.HopLog.Lines } else { @() })
        $matchedEntries = @(Build-MatchedEntries -PentahoLines $pLines -HopLines $hLines)

        $matchedRowsHtml = ""
        $matchCount = 0
        $totalEntries = $matchedEntries.Count
        foreach ($M in $matchedEntries) {
            if ($M.Verdict -eq "MATCH") { $matchCount++ }
            $mc = VerdictColor $M.Verdict
            $mi = VerdictIcon $M.Verdict
            $ml = VerdictLabel $M.Verdict

            $matchedRowsHtml += @"
<tr>
  <td class='col-cat'><span class='cat-badge'>$(CategoryLabel $M.Category)</span>$(if($M.StepName){"<div class='cat-step'>$(he $M.StepName)</div>"})</td>
  <td class='col-pentaho'><div class='entry-detail'>$(he $M.PentahoDetail)</div><div class='entry-raw' title='$(he $M.PentahoRaw)'>$(he $M.PentahoRaw)</div></td>
  <td class='col-hop'><div class='entry-detail'>$(he $M.HopDetail)</div><div class='entry-raw' title='$(he $M.HopRaw)'>$(he $M.HopRaw)</div></td>
  <td class='col-verdict'><div class='v-badge' style='background:$(VerdictColor $M.Verdict)22;color:$mc'><span>$mi</span> $ml</div><div class='v-comment'>$(he $M.Comment)</div></td>
</tr>
"@
        }

        $matchPct = $(if ($totalEntries -gt 0) { [math]::Round(($matchCount / $totalEntries) * 100, 0) } else { 100 })

        $NavChipStyle = "background:$(vb $V.Verdict);color:$Vcolor;border:1px solid $Vcolor"
        $NavItemClass = $(if ($idx -eq 1) { " active" } else { "" })
        $SidebarNavItems += @"
<button class='nav-item$NavItemClass' id='nav-$idx' onclick='focusPipeline($idx)'>
  <div class='nav-top'>
    <div class='nav-title'>$(he $R.Pipeline.id)</div>
    <span class='nav-chip' style='$NavChipStyle'>$(he $V.Verdict)</span>
  </div>
  <div class='nav-meta'>$matchCount / $totalEntries matched • $pLogCount Pentaho / $hLogCount Hop lines</div>
</button>
"@

        # ---- Dimension Cards ----
        $DimCardsHtml = ""
        foreach ($D in $V.Dimensions) {
            $dc = vc $D.Verdict
            $DimCardsHtml += @"
<div class='dim-card'>
  <div class='dim-head'><span style='color:$dc'>$(vi $D.Verdict)</span><span class='dim-label'>$($D.Label)</span><span class='dim-badge' style='background:$(vb $D.Verdict);color:$dc'>$($D.Score)/$($D.MaxScore)</span></div>
  <div class='dim-detail'>$(he $D.Detail)</div>
</div>
"@
        }

        # ---- Reasoning Chain ----
        $ReasonHtml = ""
        foreach ($line in $V.ReasoningChain) {
            $ReasonHtml += "<div class='reason-step'>$(he $line)</div>"
        }

        # ---- Divergences ----
        $DivHtml = ""
        if ($R.Divergences -and $R.Divergences.Count -gt 0) {
            foreach ($D in $R.Divergences) {
                $sc = $(if ($D.Safe) { "#10b981" } else { "#ef4444" })
                $sl = $(if ($D.Safe) { "SAFE" } else { "UNSAFE" })
                $DivHtml += @"
<div class='div-item' style='border-left-color:$sc'><div class='div-head'><span class='div-id'>$($D.DivergenceId)</span> <strong>$(he $D.Title)</strong> <span style='color:$sc;font-size:11px;font-weight:700'>[$sl]</span></div><div class='div-detail'>$(he $D.RootCause)</div>$(if(-not $D.Safe){"<div class='div-fix'>Fix: $(he $D.RecommendedFix)</div>"})</div>
"@
            }
        } else { $DivHtml = "<div class='div-none'>No known divergences matched.</div>" }

        # ---- Semantic Explanation ----
        $semanticExplanation = $(switch ($V.Verdict) {
            "PASS" { "Both logs were parsed and classified. Every crucial operation in Pentaho has a matching equivalent in Hop with identical data. <strong>The migration output is semantically equivalent.</strong>" }
            "WARN" { "Both logs were parsed and classified. The core operations match, but minor differences were detected (see entries marked with warnings above). <strong>Semantically equivalent within tolerance</strong> -- review warned items before go-live." }
            "FAIL" { "Both logs were parsed and classified. <strong>Significant differences were found</strong> that indicate the migration output is NOT equivalent. See entries marked as Missing or Delta above." }
        })

        $PipelineSections += @"
<div class='pipeline-section' id='pipeline-section-$idx' data-pipeline-index='$idx'>
  <div class='pipeline-header' onclick='toggle($idx)'>
    <div class='ph-badge' style='background:$(vb $V.Verdict);color:$Vcolor'>$(vi $V.Verdict)</div>
    <div class='ph-info'><div class='ph-name'>$($R.Pipeline.id)</div><div class='ph-desc'>$($R.Pipeline.description)</div></div>
    <div class='ph-metrics'>
      <div class='ph-m'><span class='ph-ml'>Pentaho</span><span class='ph-mv pentaho-c'>$pLogCount lines</span></div>
      <div class='ph-m'><span class='ph-ml'>Hop</span><span class='ph-mv hop-c'>$hLogCount lines</span></div>
      <div class='ph-m'><span class='ph-ml'>Matched</span><span class='ph-mv'>$matchCount / $totalEntries</span></div>
    </div>
    <div class='ph-ring'><svg viewBox='0 0 36 36'><path class='ring-bg' d='M18 2.0845a15.9155 15.9155 0 010 31.831 15.9155 15.9155 0 010-31.831'/><path class='ring-fg' stroke='$Vcolor' stroke-dasharray='$Score,100' d='M18 2.0845a15.9155 15.9155 0 010 31.831 15.9155 15.9155 0 010-31.831'/></svg><span class='ring-txt' style='color:$Vcolor'>$Score%</span></div>
    <span class='chevron' id='ch$idx'>&#9660;</span>
  </div>
  <div class='pipeline-body' id='pb$idx'>

    <!-- Matched Entries Table -->
    <div class='sec'>
      <h3 class='sec-title'>Crucial Log Entry Comparison</h3>
      <p class='sec-sub'>Each row pairs a Pentaho log entry with its Hop equivalent. The tool classified each line, matched them by operation type and step name, and rendered a semantic decision.</p>
      <div class='match-summary'><span style='color:var(--pass)'>$(vi "PASS") $matchCount matched</span> out of $totalEntries crucial entries ($matchPct% semantic match rate)</div>
      <div class='table-wrap'>
        <table class='match-table'>
          <thead>
            <tr>
              <th class='th-cat'>Operation</th>
              <th class='th-pdi'>Pentaho (Legacy) Log Entry</th>
              <th class='th-hop'>Apache Hop (Migrated) Log Entry</th>
              <th class='th-sem'>Semantic Decision</th>
            </tr>
          </thead>
          <tbody>$matchedRowsHtml</tbody>
        </table>
      </div>
    </div>

    <!-- Semantic Verdict -->
    <div class='sec'>
      <h3 class='sec-title'>Semantic Equivalence Verdict</h3>
      <div class='verdict-box' style='border-color:$Vcolor;background:$(vb $V.Verdict)'>
        <div class='vb-line'><span class='vb-icon' style='color:$Vcolor'>$(vi $V.Verdict)</span><span class='vb-label' style='color:$Vcolor'>$($V.Verdict): $($V.Summary)</span></div>
        <div class='vb-explanation'>$semanticExplanation</div>
        <div class='vb-safe' style='color:$Vcolor'>$($V.MigrationSafe)</div>
      </div>
    </div>

    <!-- Dimensions -->
    <div class='sec'>
      <h3 class='sec-title'>Scoring Dimensions</h3>
      <p class='sec-sub'>Each dimension is scored independently. The weighted total produces the overall equivalence percentage.</p>
      $DimCardsHtml
    </div>

    <!-- Reasoning -->
    <div class='sec'>
      <h3 class='sec-title'>Inference Reasoning Chain</h3>
      <div class='reason-box'>$ReasonHtml</div>
    </div>

    <!-- Divergences -->
    <div class='sec'>
      <h3 class='sec-title'>Architectural Divergences</h3>
      $DivHtml
    </div>

    <!-- Raw Logs (Collapsible) -->
    <div class='sec'>
      <h3 class='sec-title raw-toggle' onclick='toggleRaw($idx)'>Raw Logs <span class='raw-arrow' id='ra$idx'>&#9654;</span></h3>
      <div class='raw-panel' id='rp$idx'>
        <div class='raw-split'>
          <div class='raw-box'><div class='raw-header pentaho-hdr'>Pentaho Raw Log ($pLogCount lines)</div><pre class='raw-content'>$(he ([string]::Join("`n", $pLines)))</pre></div>
          <div class='raw-box'><div class='raw-header hop-hdr'>Hop Raw Log ($hLogCount lines)</div><pre class='raw-content'>$(he ([string]::Join("`n", $hLines)))</pre></div>
        </div>
      </div>
    </div>

  </div>
</div>
"@
    }

    # ===== Full HTML =======================================================
    $Html = @"
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Migration Report - $($RunSummary.RunId)</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
<style>
:root{--bg:#ffffff;--s1:#f8fafc;--s2:#f1f5f9;--b1:#e2e8f0;--b2:#cbd5e1;--t:#0f172a;--m:#475569;--pdi:#d97706;--hop:#0284c7;--pass:#059669;--warn:#d97706;--fail:#dc2626;--f:'Inter',system-ui,sans-serif;--mono:'Menlo','Monaco','Courier New',monospace}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:var(--f);background:linear-gradient(180deg,#ffffff,#f8fafc);color:var(--t);line-height:1.6;-webkit-font-smoothing:antialiased}
.container{max-width:1800px;margin:0 auto;padding:48px 52px}
.report-shell{display:grid;grid-template-columns:300px minmax(0,1fr);gap:24px;align-items:start;max-width:1800px;margin:0 auto;padding:0}
.sidebar{position:sticky;top:24px;align-self:start;background:linear-gradient(180deg,#fff,#f8fafc);border:1px solid var(--b1);border-radius:14px;padding:20px;box-shadow:0 1px 3px rgba(0,0,0,0.06);display:flex;flex-direction:column;gap:14px;max-height:calc(100vh - 56px);overflow:auto}
.sidebar-brand{font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.14em;color:var(--hop)}
.sidebar-copy{font-size:12px;color:var(--m);line-height:1.5}
.sidebar-heading{font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:var(--t)}
.sidebar-nav{display:flex;flex-direction:column;gap:10px}
.nav-item{display:flex;flex-direction:column;gap:6px;background:#fff;border:1px solid var(--b1);border-radius:10px;padding:12px 13px;text-align:left;cursor:pointer;transition:all .2s;box-shadow:0 1px 2px rgba(0,0,0,0.04)}
.nav-item:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(0,0,0,0.08)}
.nav-item.active{border-color:var(--hop);box-shadow:0 0 0 2px rgba(2,132,199,0.16),0 4px 12px rgba(0,0,0,0.08)}
.nav-top{display:flex;align-items:center;justify-content:space-between;gap:10px}
.nav-title{font-size:13px;font-weight:700;color:var(--t);line-height:1.25}
.nav-chip{display:inline-flex;align-items:center;justify-content:center;min-width:36px;padding:2px 7px;border-radius:999px;font-family:var(--mono);font-size:10px;font-weight:800}
.nav-meta{font-family:var(--mono);font-size:10px;color:var(--m)}
.sidebar-divider{height:1px;background:var(--b1)}
.sidebar-stats{display:grid;gap:8px}
.sidebar-stat{display:flex;justify-content:space-between;align-items:center;border:1px solid var(--b1);border-radius:8px;padding:10px 11px;background:rgba(255,255,255,0.72)}
.sidebar-stat-label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--m)}
.sidebar-stat-value{font-family:var(--mono);font-size:12px;font-weight:800;color:var(--t)}
.report-main{display:flex;flex-direction:column;gap:20px}
.pipeline-stream{display:flex;flex-direction:column;gap:16px}
.pipeline-section{margin-bottom:0}
.top{display:flex;justify-content:space-between;align-items:center;margin-bottom:0;padding:28px 32px;border:1px solid var(--b1);border-radius:12px;background:linear-gradient(180deg,#fff,#fbfdff);box-shadow:0 1px 3px rgba(0,0,0,0.05)}
@media (max-width:900px){.report-shell{grid-template-columns:1fr}.sidebar{position:static;max-height:none}}

/* TOP BAR */
.top-left h1{font-size:28px;font-weight:700;letter-spacing:-.02em;margin-bottom:8px;color:var(--t)}
.top-left h1 .pdi{color:var(--pdi);font-weight:800}.top-left h1 .hop{color:var(--hop);font-weight:800}
.top-meta{font-family:var(--mono);font-size:12px;color:var(--m);display:flex;gap:28px}
.top-meta strong{color:var(--t);font-weight:600}
.top-right{display:flex;gap:14px}
.sc{background:linear-gradient(135deg, var(--s1) 0%, var(--s2) 100%);border:1px solid var(--b1);border-radius:8px;padding:16px 28px;text-align:center;min-width:100px;transition:all .2s;box-shadow:0 1px 2px rgba(0,0,0,0.04)}
.sc:hover{transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,0.08)}
.sc-l{font-size:10px;text-transform:uppercase;letter-spacing:.13em;color:var(--m);margin-bottom:4px;font-weight:600}
.sc-v{font-size:28px;font-weight:800;font-family:var(--mono);color:var(--t)}

/* PIPELINE */
.pipeline-section{background:var(--bg);border:1px solid var(--b1);border-radius:10px;margin-bottom:20px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.06);transition:all .2s}
.pipeline-section:hover{box-shadow:0 4px 12px rgba(0,0,0,0.1)}
.pipeline-header{display:flex;align-items:center;padding:20px 28px;cursor:pointer;gap:18px;transition:background .15s;background:linear-gradient(to right, var(--s2), var(--s1))}
.pipeline-header:hover{background:var(--s1)}
.ph-badge{width:48px;height:48px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;font-weight:700}
.ph-info{flex:2}.ph-name{font-size:16px;font-weight:700;color:var(--t)}.ph-desc{font-size:12px;color:var(--m);margin-top:3px}
.ph-metrics{display:flex;gap:24px;flex:1.5}
.ph-m{display:flex;flex-direction:column;align-items:center}
.ph-ml{font-size:10px;text-transform:uppercase;letter-spacing:.12em;color:var(--m);font-weight:600}
.ph-mv{font-family:var(--mono);font-size:13px;font-weight:700;color:var(--t)}
.pentaho-c{color:var(--pdi)}.hop-c{color:var(--hop)}
.ph-ring{position:relative;width:56px;height:56px;flex-shrink:0}
.ph-ring svg{width:100%;height:100%;transform:rotate(-90deg)}
.ring-bg{fill:none;stroke:var(--b1);stroke-width:3}
.ring-fg{fill:none;stroke-width:3;stroke-linecap:round}
.ring-txt{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-family:var(--mono);font-size:13px;font-weight:800}
.chevron{font-size:12px;color:var(--m);transition:transform .3s;font-weight:600}
.chevron.open{transform:rotate(180deg)}

.pipeline-body{display:none;border-top:1px solid var(--b1);background:var(--bg)}
.pipeline-body.open{display:block;animation:fadeIn .25s ease}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}

/* SECTIONS */
.sec{padding:32px 36px;border-bottom:1px solid var(--b1);background:var(--bg)}
.sec:last-child{border-bottom:none}
.sec-title{font-size:11px;text-transform:uppercase;letter-spacing:.15em;color:#1e40af;font-weight:800;margin-bottom:8px}
.sec-sub{font-size:13px;color:var(--m);margin-bottom:18px;line-height:1.6}

/* MATCH TABLE */
.match-summary{font-family:var(--mono);font-size:12px;margin-bottom:16px;padding:12px 16px;background:var(--s2);border:1px solid var(--b1);border-radius:6px;display:inline-block;font-weight:500}
.table-wrap{overflow-x:auto;border:1px solid var(--b1);border-radius:8px;background:var(--bg);box-shadow:0 1px 2px rgba(0,0,0,0.04)}
.match-table{width:100%;border-collapse:collapse;font-size:13px}
.match-table th{padding:14px 18px;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:.12em;border-bottom:2px solid var(--b1);background:var(--s2);font-weight:700;color:var(--t)}
.th-cat{width:12%;color:var(--t)}
.th-pdi{width:28%;color:var(--pdi);background:rgba(217,119,6,0.04)!important}
.th-hop{width:28%;color:var(--hop);background:rgba(2,132,199,0.04)!important}
.th-sem{width:32%;color:var(--pass)}
.match-table td{padding:12px 18px;border-bottom:1px solid var(--b1);vertical-align:top;background:var(--bg)}
.match-table tr:hover{background:var(--s2)}
.col-cat{font-weight:700;color:var(--t)}
.cat-badge{display:inline-block;font-family:var(--mono);font-size:11px;padding:3px 9px;background:var(--s2);border:1px solid var(--b1);border-radius:4px;color:var(--t);font-weight:600}
.cat-step{font-family:var(--mono);font-size:12px;color:var(--m);margin-top:5px}
.col-pentaho{border-left:3px solid var(--pdi);background:rgba(217,119,6,0.02)}
.col-hop{border-left:3px solid var(--hop);background:rgba(2,132,199,0.02)}
.entry-detail{font-family:var(--mono);font-size:12px;color:var(--t);font-weight:500}
.entry-raw{font-family:var(--mono);font-size:11px;color:var(--m);margin-top:5px;opacity:.7;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:400px}
.col-verdict{border-left:3px solid var(--pass)}
.v-badge{display:inline-flex;align-items:center;gap:7px;padding:4px 12px;border-radius:12px;font-size:11px;font-weight:700;font-family:var(--mono);margin-bottom:6px}
.v-comment{font-size:12px;color:var(--m);line-height:1.6}

/* VERDICT BOX */
.verdict-box{border:2px solid;border-radius:10px;padding:28px 32px;background:var(--s1)}
.vb-line{display:flex;align-items:center;gap:12px;margin-bottom:16px}
.vb-icon{font-size:24px;font-weight:700}.vb-label{font-size:18px;font-weight:700;color:var(--t)}
.vb-explanation{font-size:14px;line-height:1.8;margin-bottom:16px;color:var(--t)}
.vb-safe{font-family:var(--mono);font-size:12px;font-weight:600;padding-top:14px;border-top:1px solid var(--b1);color:var(--m)}

/* DIMENSIONS */
.dim-card{background:var(--s1);border:1px solid var(--b1);border-radius:8px;margin-bottom:12px;overflow:hidden;transition:all .2s}
.dim-card:hover{box-shadow:0 2px 8px rgba(0,0,0,0.06)}
.dim-head{display:flex;align-items:center;gap:12px;padding:12px 16px;background:linear-gradient(135deg, var(--s2) 0%, var(--s1) 100%);border-bottom:1px solid var(--b1);font-size:13px;font-weight:600}
.dim-label{flex:1;color:var(--t)}
.dim-badge{padding:4px 12px;border-radius:14px;font-family:var(--mono);font-size:11px;font-weight:700}
.dim-detail{padding:10px 16px;font-size:12px;color:var(--m);font-family:var(--mono);background:var(--bg)}

/* REASONING */
.reason-box{background:var(--s1);border:1px solid var(--b1);border-radius:8px;padding:16px 20px}
.reason-step{font-family:var(--mono);font-size:12px;padding:7px 0;border-bottom:1px dashed var(--b1);line-height:1.7;color:var(--m)}
.reason-step:last-child{border-bottom:none}

/* DIVERGENCES */
.div-item{background:var(--s1);border:1px solid var(--b1);border-left-width:4px;border-radius:8px;padding:14px 18px;margin-bottom:10px;transition:all .2s}
.div-item:hover{box-shadow:0 2px 8px rgba(0,0,0,0.06)}
.div-head{font-size:13px;margin-bottom:8px;display:flex;align-items:center;gap:10px;font-weight:600}
.div-id{font-family:var(--mono);color:var(--m);font-size:11px}
.div-detail{font-size:12px;color:var(--m);line-height:1.6}
.div-fix{font-size:12px;color:var(--fail);margin-top:6px;font-weight:600}
.div-none{color:var(--m);font-style:italic;padding:12px 0}

/* RAW LOGS */
.raw-toggle{cursor:pointer;user-select:none;font-weight:600;color:var(--t)}
.raw-toggle:hover{color:var(--hop)}
.raw-arrow{font-size:11px;margin-left:8px;display:inline-block;transition:transform .2s;font-weight:600}
.raw-arrow.open{transform:rotate(90deg)}
.raw-panel{display:none;margin-top:14px}
.raw-panel.open{display:block}
.raw-split{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.raw-box{background:var(--s1);border:1px solid var(--b1);border-radius:8px;overflow:hidden}
.raw-header{padding:10px 16px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;border-bottom:1px solid var(--b1);background:var(--s2)}
.pentaho-hdr{color:var(--pdi);background:rgba(217,119,6,0.04)}
.hop-hdr{color:var(--hop);background:rgba(2,132,199,0.04)}
.raw-content{padding:14px 16px;font-family:var(--mono);font-size:11px;line-height:1.8;max-height:350px;overflow-y:auto;white-space:pre-wrap;word-break:break-all;color:var(--m);background:var(--bg)}

::-webkit-scrollbar{width:6px;height:6px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--b1);border-radius:3px}
::-webkit-scrollbar-thumb:hover{background:var(--b2)}

@media print{body{background:white}.container{padding:20px}._no-print{display:none!important}}
</style>
</head>
<body>
<div class="report-shell">
  <aside class="sidebar">
    <div class="sidebar-brand">Report navigation</div>
    <p class="sidebar-copy">Use the sidebar to jump straight to each pipeline, then drill into matched entries, semantic verdicts, dimensions, reasoning, and raw logs.</p>
    <div class="sidebar-heading">Pipeline index</div>
    <div class="sidebar-nav">$SidebarNavItems</div>
    <div class="sidebar-divider"></div>
    <div class="sidebar-stats">
      <div class="sidebar-stat"><span class="sidebar-stat-label">Overall verdict</span><span class="sidebar-stat-value" style="color:$OVC">$OV</span></div>
      <div class="sidebar-stat"><span class="sidebar-stat-label">Total pipelines</span><span class="sidebar-stat-value">$Total</span></div>
      <div class="sidebar-stat"><span class="sidebar-stat-label">Passed</span><span class="sidebar-stat-value" style="color:var(--pass)">$($RunSummary.Passed)</span></div>
      <div class="sidebar-stat"><span class="sidebar-stat-label">Warned</span><span class="sidebar-stat-value" style="color:var(--warn)">$($RunSummary.Warned)</span></div>
      <div class="sidebar-stat"><span class="sidebar-stat-label">Failed</span><span class="sidebar-stat-value" style="color:var(--fail)">$($RunSummary.Failed)</span></div>
    </div>
  </aside>
  <main class="report-main">
    <div class="top">
    <div class="top-left">
      <h1><span class="pdi">Pentaho</span> &#x2192; <span class="hop">Apache Hop</span> Migration Report</h1>
      <div class="top-meta"><div>Run: <strong>$($RunSummary.RunId)</strong></div><div>Duration: <strong>$($RunSummary.DurationSeconds)s</strong></div><div>Generated: <strong>$($RunSummary.EndTime)</strong></div></div>
    </div>
    <div class="top-right">
      <div class="sc"><div class="sc-l">Total</div><div class="sc-v">$Total</div></div>
      <div class="sc"><div class="sc-l" style="color:var(--pass)">Pass</div><div class="sc-v" style="color:var(--pass)">$($RunSummary.Passed)</div></div>
      <div class="sc"><div class="sc-l" style="color:var(--warn)">Warn</div><div class="sc-v" style="color:var(--warn)">$($RunSummary.Warned)</div></div>
      <div class="sc"><div class="sc-l" style="color:var(--fail)">Fail</div><div class="sc-v" style="color:var(--fail)">$($RunSummary.Failed)</div></div>
      <div class="sc" style="border-color:$OVC"><div class="sc-l">Verdict</div><div class="sc-v" style="color:$OVC">$OV</div></div>
    </div>
    </div>
    <section class="pipeline-stream">
      $PipelineSections
    </section>
  </main>
</div>
<script>
function activateNav(i){
  document.querySelectorAll('.nav-item').forEach(function(el){el.classList.remove('active')});
  var nav = document.getElementById('nav-'+i);
  if (nav) { nav.classList.add('active'); }
}
function focusPipeline(i){
  var panel = document.getElementById('pipeline-section-'+i);
  var body = document.getElementById('pb'+i);
  var che = document.getElementById('ch'+i);
  document.querySelectorAll('.pipeline-body').forEach(function(x){x.classList.remove('open')});
  document.querySelectorAll('.chevron').forEach(function(x){x.classList.remove('open')});
  if (body) { body.classList.add('open'); }
  if (che) { che.classList.add('open'); }
  activateNav(i);
  if (panel) {
    panel.scrollIntoView({behavior:'smooth', block:'start'});
  }
}
function toggle(i){
  var b=document.getElementById('pb'+i),c=document.getElementById('ch'+i),o=b.classList.contains('open');
  document.querySelectorAll('.pipeline-body').forEach(function(x){x.classList.remove('open')});
  document.querySelectorAll('.chevron').forEach(function(x){x.classList.remove('open')});
  if(!o){
    b.classList.add('open');
    c.classList.add('open');
    activateNav(i);
    var panel=document.getElementById('pipeline-section-'+i);
    if (panel) { panel.scrollIntoView({behavior:'smooth', block:'start'}); }
  } else {
    activateNav(i);
  }
}
function toggleRaw(i){var p=document.getElementById('rp'+i),a=document.getElementById('ra'+i);p.classList.toggle('open');a.classList.toggle('open')}

document.addEventListener('DOMContentLoaded', function(){
  if (document.getElementById('nav-1')) {
    focusPipeline(1);
  }
});
</script>
</body>
</html>
"@

    $bom = New-Object System.Text.UTF8Encoding $true
    [System.IO.File]::WriteAllText($OutputPath, $Html, $bom)
    return $OutputPath
}
