﻿<#
.SYNOPSIS
    Build-Verdict.ps1
    Assembles the final pipeline verdict from the equivalence score and
    matched divergences. Produces a full reasoning chain explaining every
    decision. This is the top of the inference stack.

    Decision logic:
    1. Hard fail (exit code mismatch) -> always FAIL
    2. Any unsafe known divergence matched -> FAIL
    3. Score >= pass threshold AND no unsafe divergences -> PASS
    4. Score >= warn threshold -> WARN
    5. Score < warn threshold -> FAIL
#>

function Build-PipelineVerdict {
    param(
        [Parameter(Mandatory)] $Score,
        [Parameter(Mandatory)] $Divergences,
        [Parameter(Mandatory)] $Pipeline,
        [Parameter(Mandatory)] $KB
    )

    $Thresholds   = $KB.Weights.thresholds
    $ReasonChain  = [System.Collections.Generic.List[string]]::new()
    $AppliedRules = [System.Collections.Generic.List[string]]::new()

    # -- Determine raw verdict from score ------------------------------
    $RawVerdict = $(if     ($Score.TotalScore -ge $Thresholds.pass) { "PASS" }
                  elseif ($Score.TotalScore -ge $Thresholds.warn) { "WARN" }
                  else   { "FAIL" })

    # -- Build dimension reasoning --------------------------------------
    foreach ($Dim in $Score.Dimensions) {
        $icon = switch ($Dim.Verdict) { "PASS" { "✓" } "WARN" { "⚠" } "FAIL" { "✗" } default { "·" } }
        $label = $(if ($Dim.Label) { $Dim.Label } else { $Dim.DimensionId })
        $ReasonChain.Add("[$icon] [$($Dim.Score)/$($Dim.Weight)] $($label): $($Dim.Detail)")
    }

    # -- Apply hard fail override ---------------------------------------
    if ($Score.HardFail) {
        $RawVerdict = "FAIL"
        $ReasonChain.Add("✗ [HARD FAIL] Exit code mismatch - overrides all other checks")
        $AppliedRules.Add("HARD-FAIL-EXIT-CODE")
    }

    # -- Apply divergence adjustments ----------------------------------
    $UnsafeDivergences = @($Divergences | Where-Object { $_.Safe -eq $false })
    $SafeDivergences   = @($Divergences | Where-Object { $_.Safe -eq $true })

    foreach ($D in $SafeDivergences) {
        $ReasonChain.Add("⬡ [KD:$($D.DivergenceId)] $($D.Title): $($D.Evidence)")
        $AppliedRules.Add($D.DivergenceId)
        # Safe divergence can upgrade WARN to WARN (no downgrade)
        if ($RawVerdict -eq "FAIL" -and $D.Verdict -eq "WARN") {
            # Only upgrade if the failure was ONLY due to this known-safe divergence
            # Check if all FAIL dimensions are explained by this divergence
            $FailDims = @($Score.Dimensions | Where-Object Verdict -eq "FAIL")
            if ($FailDims.Count -eq 0) { $RawVerdict = "WARN" }
        }
    }

    foreach ($D in $UnsafeDivergences) {
        $RawVerdict = "FAIL"
        $ReasonChain.Add("✗ [KD:$($D.DivergenceId) UNSAFE] $($D.Title): $($D.Evidence)")
        $ReasonChain.Add("  -> Fix: $($D.RecommendedFix)")
        $AppliedRules.Add($D.DivergenceId)
    }

    # -- Build summary --------------------------------------------------
    $Summary = switch ($RawVerdict) {
        "PASS" {
            "All equivalence checks passed (score=$($Score.TotalScore)%) - functionally identical"
        }
        "WARN" {
            $WarnDims = ($Score.Dimensions | Where-Object Verdict -eq "WARN" | ForEach-Object { $_.Label -or $_.DimensionId }) -join ", "
            $KDTitles = ($SafeDivergences  | ForEach-Object { $_.DivergenceId })   -join ", "
            "Within tolerance (score=$($Score.TotalScore)%) - known divergences: $KDTitles"
        }
        "FAIL" {
            $FailDims   = ($Score.Dimensions | Where-Object Verdict -eq "FAIL" | ForEach-Object { $_.Label -or $_.DimensionId }) -join ", "
            $UnsafeKDs  = ($UnsafeDivergences  | ForEach-Object { "$($_.DivergenceId):$($_.Title)" }) -join ", "
            $Parts = @()
            if ($FailDims)  { $Parts += "Failed dimensions: $FailDims" }
            if ($UnsafeKDs) { $Parts += "Unsafe divergences: $UnsafeKDs" }
            if ($Score.HardFail) { $Parts += "Hard fail: exit code mismatch" }
            "FAILED (score=$($Score.TotalScore)%) - $($Parts -join ' | ')"
        }
    }

    # -- Migration safety statement -------------------------------------
    $MigrationSafe = switch ($RawVerdict) {
        "PASS" { "YES - Migration safe. Hop output is functionally equivalent to Pentaho." }
        "WARN" { "YES WITH NOTES - Migration safe within configured tolerance. Review warned items before go-live." }
        "FAIL" { "NO - Migration not safe. Investigate failed checks before deploying to production." }
    }

    return [PSCustomObject]@{
        PipelineId       = $Pipeline.id
        Verdict          = $RawVerdict
        Score            = $Score.TotalScore
        Summary          = $Summary
        MigrationSafe    = $MigrationSafe
        ReasoningChain   = $ReasonChain.ToArray()
        AppliedRules     = $AppliedRules.ToArray()
        DivergencesFound = $Divergences.Count
        SafeDivergences  = $SafeDivergences
        UnsafeDivergences= $UnsafeDivergences
        Dimensions       = $Score.Dimensions
        ComparedAt       = (Get-Date).ToString("o")
    }
}


