﻿function Initialize-KnowledgeBase {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$KnowledgeBasePath
    )

    if (-not (Test-Path $KnowledgeBasePath)) {
        throw "Knowledge base path not found: $KnowledgeBasePath"
    }

    return [PSCustomObject]@{
        Patterns              = (Get-Content "$KnowledgeBasePath/semantic_patterns.json" -Raw | ConvertFrom-Json).patterns
        Divergences           = (Get-Content "$KnowledgeBasePath/known_divergences.json" -Raw | ConvertFrom-Json).divergences
        Weights               = (Get-Content "$KnowledgeBasePath/equivalence_weights.json" -Raw | ConvertFrom-Json)
        TransformEquivalency  = (Get-Content "$KnowledgeBasePath/transform_equivalency.json" -Raw | ConvertFrom-Json)
        CompatibilityRules    = (Get-Content "$KnowledgeBasePath/compatibility_rules.json" -Raw | ConvertFrom-Json)
        RuntimeProfiles       = (Get-Content "$KnowledgeBasePath/runtime_behavior_profiles.json" -Raw | ConvertFrom-Json)
    }
}


