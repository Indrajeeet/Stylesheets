# Enterprise Pentaho → Apache Hop Migration Validation Harness

## Features

- Canonical event extraction
- Semantic equivalence scoring
- Known divergence detection
- HTML + JSON + JUnit reporting
- Enterprise knowledge-base architecture
- CI/CD friendly execution
- Strict PowerShell standards
- Modularized KB initialization
- Compatibility intelligence for Pentaho → Hop migration

## New Enterprise Enhancements

### Knowledge Base Extensions

- transform_equivalency.json
- runtime_behavior_profiles.json
- compatibility_rules.json

### Enterprise Engineering

- StrictMode enabled globally
- Modular knowledge base initialization
- Structured information logging
- JUnit report support
- Extensible module architecture

## Execution

```powershell
pwsh ./Run-MigrationTest.ps1
```

## CI/CD Example

```yaml
- name: Run migration validation
  shell: pwsh
  run: ./Run-MigrationTest.ps1
```
